create
    definer = root@localhost procedure bbb()
BEGIN
	#Routine body goes here...

	declare i int default 101;
	myloop:loop
		insert into d values (i, 'aaa', 'bbb');
		set i=i+1;
		if i>200 then
			leave myloop;
		end if;
	end loop;
END;

