create
    definer = root@localhost procedure aaa()
BEGIN
	#Routine body goeselecs here...
select * from d;
	
END;

