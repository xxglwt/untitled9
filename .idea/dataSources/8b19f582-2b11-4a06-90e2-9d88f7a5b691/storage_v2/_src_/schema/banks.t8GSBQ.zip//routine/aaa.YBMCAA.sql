create
    definer = root@localhost procedure aaa()
BEGIN
	#Routine body goes here...
declare i int default 101;
	myloop:loop
		insert into renyuan (bianhao) values (i);
		set i=i+1;
		if i>200 then
			leave myloop;
		end if;
	end loop;
END;

