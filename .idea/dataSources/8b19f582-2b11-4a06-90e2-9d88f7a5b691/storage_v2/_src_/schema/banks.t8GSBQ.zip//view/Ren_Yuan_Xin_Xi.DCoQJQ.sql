create view 人员信息 as
select `banks`.`renyuan`.`xingming` AS `姓名`,
       `banks`.`renyuan`.`xingbie`  AS `性别`,
       `banks`.`renyuan`.`age`      AS `年龄`,
       `banks`.`bumen`.`mc`         AS `部门名称`
from (`banks`.`bumen`
         join `banks`.`renyuan` on ((`banks`.`bumen`.`bh` = `banks`.`renyuan`.`bh`)));

